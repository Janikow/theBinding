"use strict";

const { createLogger, format, transports } = require("winston");
require("winston-daily-rotate-file");
const path = require("path");
const fs = require("fs");

let _logger = null;

function createAppLogger(config) {
  const logConfig = config.logging || {};
  const { level = "info", file = {}, console: consoleOpts = {} } = logConfig;

  const logTransports = [];

  // Console transport
  if (consoleOpts.enabled !== false) {
    logTransports.push(
      new transports.Console({
        format: format.combine(
          format.colorize({ all: consoleOpts.colorize !== false }),
          format.timestamp({ format: "HH:mm:ss" }),
          format.printf(({ timestamp, level, message, ...meta }) => {
            const extras = Object.keys(meta).length ? " " + JSON.stringify(meta) : "";
            return `${timestamp} [${level}] ${message}${extras}`;
          })
        ),
      })
    );
  }

  // File transport (rotating)
  if (file.enabled !== false) {
    const logDir = file.dir || "./logs";
    if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });

    logTransports.push(
      new transports.DailyRotateFile({
        dirname: logDir,
        filename: "ultraproxy-%DATE%.log",
        datePattern: "YYYY-MM-DD",
        maxSize: file.maxSize || "20m",
        maxFiles: file.maxFiles || "14d",
        format: format.combine(
          format.timestamp(),
          format.json()
        ),
      })
    );

    // Separate error log
    logTransports.push(
      new transports.DailyRotateFile({
        dirname: logDir,
        filename: "ultraproxy-error-%DATE%.log",
        datePattern: "YYYY-MM-DD",
        level: "error",
        maxSize: file.maxSize || "20m",
        maxFiles: file.maxFiles || "14d",
        format: format.combine(
          format.timestamp(),
          format.json()
        ),
      })
    );
  }

  _logger = createLogger({
    level,
    format: format.combine(
      format.errors({ stack: true }),
      format.splat()
    ),
    transports: logTransports,
    exitOnError: false,
  });

  return _logger;
}

function getLogger() {
  if (!_logger) {
    // Fallback minimal logger
    _logger = createLogger({
      level: "info",
      transports: [new transports.Console()],
    });
  }
  return _logger;
}

module.exports = { createAppLogger, getLogger };
