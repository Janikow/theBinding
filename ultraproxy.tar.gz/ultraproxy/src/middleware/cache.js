"use strict";

const NodeCache = require("node-cache");
const { getLogger } = require("../utils/logger");
const metrics = require("../utils/metrics");

let _cache = null;

function initCache(config) {
  _cache = new NodeCache({
    stdTTL: config.cache?.defaultTtl || 60,
    maxKeys: config.cache?.maxKeys || 500,
    checkperiod: 120,
    useClones: false,
  });
  getLogger().info(`[Cache] Initialized (TTL=${config.cache?.defaultTtl}s, maxKeys=${config.cache?.maxKeys})`);
  return _cache;
}

function getCache() {
  return _cache;
}

/**
 * Express middleware that caches GET/HEAD responses
 */
function cacheMiddleware(ttl) {
  return (req, res, next) => {
    if (!_cache) return next();

    // Only cache configured methods
    if (!["GET", "HEAD"].includes(req.method)) return next();

    const key = `${req.method}:${req.originalUrl}`;
    const cached = _cache.get(key);

    if (cached) {
      metrics.recordRequest({
        method: req.method,
        path: req.originalUrl,
        status: cached.status,
        cached: true,
        latencyMs: 0,
      });
      res.set(cached.headers || {});
      res.set("X-Cache", "HIT");
      res.status(cached.status).send(cached.body);
      return;
    }

    // Intercept response to cache it
    const originalSend = res.send.bind(res);
    res.send = function (body) {
      if (res.statusCode >= 200 && res.statusCode < 300) {
        const headers = {};
        ["content-type", "content-encoding", "content-language"].forEach((h) => {
          const v = res.getHeader(h);
          if (v) headers[h] = v;
        });
        _cache.set(key, { status: res.statusCode, body, headers }, ttl || undefined);
        res.set("X-Cache", "MISS");
      }
      originalSend(body);
    };

    next();
  };
}

function getCacheStats() {
  if (!_cache) return null;
  return _cache.getStats();
}

function clearCache() {
  if (_cache) _cache.flushAll();
}

module.exports = { initCache, getCache, cacheMiddleware, getCacheStats, clearCache };
