"use strict";

const http = require("http");
const https = require("https");
const net = require("net");
const url = require("url");
const micromatch = require("micromatch");
const { getLogger } = require("../utils/logger");
const { checkForwardProxyAuth } = require("../middleware/auth");
const metrics = require("../utils/metrics");

/**
 * Creates a standalone HTTP forward proxy server.
 *
 * Supports:
 *  - Plain HTTP proxying (GET, POST, etc.)
 *  - HTTPS via CONNECT tunneling (transparent TLS passthrough)
 *  - Basic proxy authentication
 *  - Domain allow/block lists
 *  - Request/response logging
 */
function createForwardProxy(config) {
  const proxyConfig = config.forwardProxy || {};
  const logger = getLogger();

  function isDomainBlocked(host) {
    const blocklist = proxyConfig.blocklist || [];
    if (blocklist.length && micromatch([host], blocklist).length) return true;
    const allowlist = proxyConfig.allowlist || [];
    if (allowlist.length && !micromatch([host], allowlist).length) return true;
    return false;
  }

  function injectHeaders(headers) {
    const injected = { ...headers };
    const configHeaders = config.headers?.inject || {};
    Object.assign(injected, configHeaders);
    // Remove hop-by-hop headers
    const hopByHop = ["connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
      "te", "trailers", "transfer-encoding", "upgrade", "proxy-connection"];
    hopByHop.forEach((h) => delete injected[h]);
    (config.headers?.remove || []).forEach((h) => delete injected[h.toLowerCase()]);
    return injected;
  }

  const server = http.createServer((req, res) => {
    const start = Date.now();

    // Auth check
    if (!checkForwardProxyAuth(config, req)) {
      res.writeHead(407, { "Proxy-Authenticate": 'Basic realm="UltraProxy"' });
      res.end("Proxy Authentication Required");
      return;
    }

    let parsedUrl;
    try {
      parsedUrl = url.parse(req.url);
    } catch (e) {
      res.writeHead(400);
      res.end("Bad Request");
      return;
    }

    const host = parsedUrl.hostname;
    const port = parsedUrl.port || (parsedUrl.protocol === "https:" ? 443 : 80);
    const path = parsedUrl.path || "/";

    // Domain check
    if (isDomainBlocked(host)) {
      logger.warn(`[Forward] Blocked: ${host}`);
      metrics.recordRequest({ method: req.method, path: host, status: 403, blocked: true });
      res.writeHead(403);
      res.end("Forbidden: this domain is blocked");
      return;
    }

    const options = {
      hostname: host,
      port: parseInt(port),
      path,
      method: req.method,
      headers: injectHeaders(req.headers),
      timeout: proxyConfig.timeout || 30000,
    };

    const mod = parsedUrl.protocol === "https:" ? https : http;

    const proxyReq = mod.request(options, (proxyRes) => {
      const latencyMs = Date.now() - start;

      // Inject response headers
      const responseHeaders = { ...proxyRes.headers };
      const configResponseHeaders = config.headers?.response || {};
      Object.assign(responseHeaders, configResponseHeaders);
      delete responseHeaders["transfer-encoding"]; // Let Node handle this

      res.writeHead(proxyRes.statusCode, responseHeaders);
      proxyRes.pipe(res, { end: true });

      metrics.recordRequest({
        method: req.method,
        path: host + path,
        status: proxyRes.statusCode,
        latencyMs,
        target: host,
      });

      if (config.logging?.requestLog) {
        logger.info(`[Forward] ${req.method} ${host}${path} → ${proxyRes.statusCode} (${latencyMs}ms)`);
      }
    });

    proxyReq.on("error", (err) => {
      const latencyMs = Date.now() - start;
      logger.error(`[Forward] Error proxying ${host}: ${err.message}`);
      metrics.recordRequest({ method: req.method, path: host, status: 502, error: err.message, latencyMs });
      if (!res.headersSent) {
        res.writeHead(502);
        res.end(`Bad Gateway: ${err.message}`);
      }
    });

    proxyReq.on("timeout", () => {
      proxyReq.destroy();
      if (!res.headersSent) {
        res.writeHead(504);
        res.end("Gateway Timeout");
      }
    });

    req.pipe(proxyReq, { end: true });
  });

  // ── CONNECT handler (HTTPS tunneling) ─────────────────────
  server.on("connect", (req, clientSocket, head) => {
    const start = Date.now();
    const [host, portStr] = req.url.split(":");
    const port = parseInt(portStr) || 443;

    // Auth
    if (!checkForwardProxyAuth(config, req)) {
      clientSocket.write("HTTP/1.1 407 Proxy Authentication Required\r\nProxy-Authenticate: Basic realm=\"UltraProxy\"\r\n\r\n");
      clientSocket.destroy();
      return;
    }

    // Block list
    if (isDomainBlocked(host)) {
      logger.warn(`[Forward CONNECT] Blocked: ${host}`);
      clientSocket.write("HTTP/1.1 403 Forbidden\r\n\r\n");
      clientSocket.destroy();
      return;
    }

    // Create TCP tunnel
    const serverSocket = net.connect(port, host, () => {
      clientSocket.write("HTTP/1.1 200 Connection Established\r\nProxy-agent: UltraProxy/1.0\r\n\r\n");

      serverSocket.write(head);
      serverSocket.pipe(clientSocket, { end: false });
      clientSocket.pipe(serverSocket, { end: false });

      if (config.logging?.requestLog) {
        logger.info(`[Forward CONNECT] TUNNEL ${host}:${port}`);
      }
    });

    serverSocket.on("error", (err) => {
      logger.error(`[Forward CONNECT] Error connecting to ${host}:${port}: ${err.message}`);
      metrics.recordRequest({ method: "CONNECT", path: host, status: 502, error: err.message, latencyMs: Date.now() - start });
      clientSocket.write("HTTP/1.1 502 Bad Gateway\r\n\r\n");
      clientSocket.destroy();
    });

    serverSocket.setTimeout(proxyConfig.timeout || 30000, () => {
      serverSocket.destroy();
      clientSocket.destroy();
    });

    clientSocket.on("error", () => serverSocket.destroy());
    serverSocket.on("close", () => clientSocket.destroy());
    clientSocket.on("close", () => serverSocket.destroy());
  });

  server.on("error", (err) => {
    getLogger().error(`[Forward Proxy] Server error: ${err.message}`);
  });

  return server;
}

module.exports = { createForwardProxy };
