"use strict";

const fs = require("fs");
const path = require("path");
const yaml = require("js-yaml");
require("dotenv").config();

const CONFIG_PATH = process.env.CONFIG_PATH || path.join(__dirname, "../../config.yaml");

function loadConfig() {
  let config = {};

  // Load YAML config
  if (fs.existsSync(CONFIG_PATH)) {
    try {
      const raw = fs.readFileSync(CONFIG_PATH, "utf8");
      config = yaml.load(raw);
    } catch (err) {
      console.error("[Config] Failed to parse config.yaml:", err.message);
      process.exit(1);
    }
  } else {
    console.warn(`[Config] No config file found at ${CONFIG_PATH}, using defaults`);
  }

  // Environment variable overrides
  const env = process.env;

  if (env.PORT)               config.server = { ...config.server, port: parseInt(env.PORT) };
  if (env.HTTPS_PORT)         config.server = { ...config.server, httpsPort: parseInt(env.HTTPS_PORT) };
  if (env.FORWARD_PROXY_PORT) config.forwardProxy = { ...config.forwardProxy, port: parseInt(env.FORWARD_PROXY_PORT) };
  if (env.ADMIN_PORT)         config.admin = { ...config.admin, port: parseInt(env.ADMIN_PORT) };
  if (env.LOG_LEVEL)          config.logging = { ...config.logging, level: env.LOG_LEVEL };
  if (env.AUTH_ENABLED)       config.auth = { ...config.auth, enabled: env.AUTH_ENABLED === "true" };
  if (env.ADMIN_KEY)          config.auth = { ...config.auth, adminKey: env.ADMIN_KEY };
  if (env.JWT_SECRET)         config.auth = { ...config.auth, jwt: { ...(config.auth?.jwt || {}), secret: env.JWT_SECRET } };

  // Merge defaults
  config.server        = { port: 8080, httpsPort: 8443, host: "0.0.0.0", trustProxy: true, ...config.server };
  config.auth          = { enabled: false, apiKeys: [], adminKey: "changeme", jwt: { secret: "changeme", expiresIn: "24h" }, ...config.auth };
  config.rateLimit     = { enabled: true, windowMs: 60000, max: 300, ...config.rateLimit };
  config.forwardProxy  = { enabled: true, port: 3128, timeout: 30000, blocklist: [], allowlist: [], auth: { enabled: false }, ...config.forwardProxy };
  config.loadBalancer  = { enabled: false, algorithm: "round-robin", pools: [], ...config.loadBalancer };
  config.cache         = { enabled: true, defaultTtl: 60, maxKeys: 500, methods: ["GET", "HEAD"], ...config.cache };
  config.cors          = { enabled: true, origin: "*", methods: ["GET","POST","PUT","DELETE","PATCH","OPTIONS"], ...config.cors };
  config.logging       = { level: "info", requestLog: true, responseLog: false, file: { enabled: true, dir: "./logs" }, console: { enabled: true, colorize: true }, ...config.logging };
  config.headers       = { inject: {}, remove: [], response: {}, ...config.headers };
  config.admin         = { enabled: true, port: 9000, path: "/", requireAuth: false, ...config.admin };
  config.routes        = config.routes || [];
  config.transforms    = { enabled: false, rules: [], ...config.transforms };
  config.ssl           = { enabled: false, cert: "./ssl/server.crt", key: "./ssl/server.key", ...config.ssl };

  return config;
}

// Singleton config
let _config = null;
function getConfig() {
  if (!_config) _config = loadConfig();
  return _config;
}

function reloadConfig() {
  _config = loadConfig();
  return _config;
}

module.exports = { getConfig, reloadConfig };
