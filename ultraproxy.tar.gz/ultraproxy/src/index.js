#!/usr/bin/env node
"use strict";

const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");
const chalk = require("chalk");

const { getConfig } = require("./utils/config");
const { createAppLogger, getLogger } = require("./utils/logger");
const { buildApp } = require("./server");
const { createForwardProxy } = require("./routes/forwardProxy");
const { handleUpgrade } = require("./routes/reverseProxy");

// ── Bootstrap ─────────────────────────────────────────────────
async function main() {
  const config = getConfig();
  const logger = createAppLogger(config);

  // ── Splash ─────────────────────────────────────────────────
  console.log(chalk.cyan("\n  ██╗   ██╗██╗  ████████╗██████╗  █████╗ ██████╗ ██████╗  ██████╗ ██╗  ██╗██╗   ██╗"));
  console.log(chalk.cyan("  ██║   ██║██║  ╚══██╔══╝██╔══██╗██╔══██╗██╔══██╗██╔══██╗██╔═══██╗╚██╗██╔╝╚██╗ ██╔╝"));
  console.log(chalk.cyan("  ██║   ██║██║     ██║   ██████╔╝███████║██████╔╝██████╔╝██║   ██║ ╚███╔╝  ╚████╔╝ "));
  console.log(chalk.cyan("  ██║   ██║██║     ██║   ██╔══██╗██╔══██║██╔═══╝ ██╔══██╗██║   ██║ ██╔██╗   ╚██╔╝  "));
  console.log(chalk.cyan("  ╚██████╔╝███████╗██║   ██║  ██║██║  ██║██║     ██║  ██║╚██████╔╝██╔╝ ██╗   ██║   "));
  console.log(chalk.cyan("   ╚═════╝ ╚══════╝╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   \n"));
  console.log(chalk.gray("  Production-grade proxy server v1.0.0\n"));

  const app = buildApp(config);
  const host = config.server.host || "0.0.0.0";

  // ── HTTP server ─────────────────────────────────────────────
  const httpServer = http.createServer(app);

  // WebSocket upgrade passthrough
  httpServer.on("upgrade", (req, socket, head) => {
    handleUpgrade(req, socket, head, config);
  });

  await new Promise((resolve, reject) => {
    httpServer.listen(config.server.port, host, () => {
      logger.info(chalk.green(`  ✓ HTTP server     `) + chalk.white(`http://${host}:${config.server.port}`));
      resolve();
    });
    httpServer.on("error", reject);
  });

  // ── HTTPS server ─────────────────────────────────────────────
  if (config.ssl?.enabled) {
    try {
      const sslOptions = {
        cert: fs.readFileSync(config.ssl.cert),
        key:  fs.readFileSync(config.ssl.key),
      };
      if (config.ssl.ca) sslOptions.ca = fs.readFileSync(config.ssl.ca);

      const httpsServer = https.createServer(sslOptions, app);
      httpsServer.on("upgrade", (req, socket, head) => handleUpgrade(req, socket, head, config));

      await new Promise((resolve, reject) => {
        httpsServer.listen(config.server.httpsPort, host, () => {
          logger.info(chalk.green(`  ✓ HTTPS server    `) + chalk.white(`https://${host}:${config.server.httpsPort}`));
          resolve();
        });
        httpsServer.on("error", reject);
      });
    } catch (err) {
      logger.warn(`  ⚠ HTTPS skipped: ${err.message}`);
    }
  }

  // ── Forward proxy ─────────────────────────────────────────────
  if (config.forwardProxy?.enabled) {
    const fwdServer = createForwardProxy(config);
    await new Promise((resolve, reject) => {
      fwdServer.listen(config.forwardProxy.port, host, () => {
        logger.info(chalk.green(`  ✓ Forward proxy   `) + chalk.white(`http://${host}:${config.forwardProxy.port}`));
        resolve();
      });
      fwdServer.on("error", (err) => {
        logger.error(`  ✗ Forward proxy failed: ${err.message}`);
        resolve(); // Non-fatal
      });
    });
  }

  // ── Admin dashboard ────────────────────────────────────────────
  if (config.admin?.enabled) {
    logger.info(chalk.green(`  ✓ Admin dashboard `) + chalk.white(`http://${host}:${config.server.port}/admin`));
  }

  // ── Summary ────────────────────────────────────────────────────
  console.log(chalk.gray("\n  ─────────────────────────────────────────────"));
  logger.info(`  Routes configured:   ${(config.routes || []).length}`);
  logger.info(`  Load balancer:       ${config.loadBalancer?.enabled ? `on (${config.loadBalancer.algorithm})` : "off"}`);
  logger.info(`  Auth:                ${config.auth?.enabled ? "on" : "off"}`);
  logger.info(`  Cache:               ${config.cache?.enabled ? `on (TTL=${config.cache.defaultTtl}s)` : "off"}`);
  logger.info(`  Rate limiting:       ${config.rateLimit?.enabled ? `on (${config.rateLimit.max} req/${config.rateLimit.windowMs / 1000}s)` : "off"}`);
  logger.info(`  Environment:         ${process.env.NODE_ENV || "development"}`);
  console.log(chalk.gray("  ─────────────────────────────────────────────\n"));

  // ── Graceful shutdown ──────────────────────────────────────────
  const shutdown = (signal) => {
    logger.info(`\n  Received ${signal}, shutting down gracefully…`);
    httpServer.close(() => {
      logger.info("  HTTP server closed.");
      process.exit(0);
    });
    setTimeout(() => {
      logger.warn("  Forced shutdown after timeout.");
      process.exit(1);
    }, 10000);
  };

  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT",  () => shutdown("SIGINT"));
  process.on("uncaughtException",  (err) => logger.error(`Uncaught exception: ${err.message}`, { stack: err.stack }));
  process.on("unhandledRejection", (err) => logger.error(`Unhandled rejection: ${err}`));
}

main().catch((err) => {
  console.error(chalk.red("\n  Fatal error during startup:"), err.message);
  process.exit(1);
});
