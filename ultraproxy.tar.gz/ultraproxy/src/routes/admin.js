"use strict";

const express = require("express");
const { adminAuth, issueToken } = require("../middleware/auth");
const metrics = require("../utils/metrics");
const { getCacheStats, clearCache } = require("../middleware/cache");
const { getLB } = require("./reverseProxy");
const { reloadConfig } = require("../utils/config");
const { getLogger } = require("../utils/logger");

function createAdminRouter(config) {
  const router = express.Router();
  const auth = adminAuth(config);

  // ── Token issue (login) ────────────────────────────────────
  router.post("/auth/token", (req, res) => {
    const { adminKey } = req.body || {};
    if (adminKey !== config.auth?.adminKey) {
      return res.status(401).json({ error: "Invalid admin key" });
    }
    const token = issueToken(config, { role: "admin" });
    res.json({ token, expiresIn: config.auth?.jwt?.expiresIn || "24h" });
  });

  // All routes below require auth
  router.use(auth);

  // ── Health ─────────────────────────────────────────────────
  router.get("/health", (req, res) => {
    res.json({ status: "ok", uptime: process.uptime(), pid: process.pid, nodeVersion: process.version });
  });

  // ── Metrics ────────────────────────────────────────────────
  router.get("/metrics", (req, res) => {
    const summary = metrics.getSummary();
    res.json(summary);
  });

  router.get("/metrics/recent", (req, res) => {
    const limit = parseInt(req.query.limit) || 50;
    res.json(metrics.recentRequests.slice(-limit).reverse());
  });

  router.get("/metrics/errors", (req, res) => {
    res.json(metrics.errors.slice(-100).reverse());
  });

  router.post("/metrics/reset", (req, res) => {
    metrics.reset();
    getLogger().info("[Admin] Metrics reset");
    res.json({ message: "Metrics reset" });
  });

  // ── Cache ──────────────────────────────────────────────────
  router.get("/cache/stats", (req, res) => {
    res.json(getCacheStats() || { message: "Cache not initialized" });
  });

  router.delete("/cache", (req, res) => {
    clearCache();
    getLogger().info("[Admin] Cache cleared");
    res.json({ message: "Cache cleared" });
  });

  // ── Load Balancer ──────────────────────────────────────────
  router.get("/lb/status", (req, res) => {
    const lb = getLB();
    if (!lb) return res.json({ enabled: false });
    res.json({ enabled: true, algorithm: config.loadBalancer?.algorithm, pools: lb.getStatus() });
  });

  // ── Config ─────────────────────────────────────────────────
  router.get("/config", (req, res) => {
    // Return safe subset (strip secrets)
    const safe = JSON.parse(JSON.stringify(config));
    if (safe.auth) {
      safe.auth.apiKeys = safe.auth.apiKeys?.map(() => "***");
      safe.auth.adminKey = "***";
      if (safe.auth.jwt) safe.auth.jwt.secret = "***";
    }
    if (safe.forwardProxy?.auth) safe.forwardProxy.auth.password = "***";
    res.json(safe);
  });

  router.post("/config/reload", (req, res) => {
    try {
      const newConfig = reloadConfig();
      getLogger().info("[Admin] Config reloaded");
      res.json({ message: "Config reloaded", routes: newConfig.routes?.length, loadBalancer: newConfig.loadBalancer?.enabled });
    } catch (e) {
      res.status(500).json({ error: "Failed to reload config", message: e.message });
    }
  });

  // ── Process ────────────────────────────────────────────────
  router.get("/process", (req, res) => {
    res.json({
      pid: process.pid,
      uptime: process.uptime(),
      memoryUsage: process.memoryUsage(),
      cpuUsage: process.cpuUsage(),
      nodeVersion: process.version,
      platform: process.platform,
      env: process.env.NODE_ENV || "development",
    });
  });

  return router;
}

module.exports = { createAdminRouter };
