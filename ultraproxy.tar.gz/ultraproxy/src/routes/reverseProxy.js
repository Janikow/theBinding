"use strict";

const httpProxy = require("http-proxy");
const { getLogger } = require("../utils/logger");
const { cacheMiddleware } = require("../middleware/cache");
const metrics = require("../utils/metrics");
const LoadBalancer = require("../utils/loadBalancer");

let _proxy = null;
let _lb = null;

function setupReverseProxy(app, config) {
  const logger = getLogger();

  // Single shared proxy instance
  _proxy = httpProxy.createProxyServer({
    changeOrigin: true,
    selfHandleResponse: false,
    timeout: 30000,
    proxyTimeout: 30000,
  });

  _proxy.on("error", (err, req, res) => {
    logger.error(`[Reverse] Proxy error: ${err.message}`);
    metrics.recordRequest({ method: req.method, path: req.url, status: 502, error: err.message, latencyMs: Date.now() - (req._startTime || Date.now()) });
    if (!res.headersSent) {
      res.status(502).json({ error: "Bad Gateway", message: err.message });
    }
  });

  _proxy.on("proxyReq", (proxyReq, req, res) => {
    // Inject configured headers
    const inject = config.headers?.inject || {};
    Object.entries(inject).forEach(([k, v]) => proxyReq.setHeader(k, v));

    // Remove configured headers
    (config.headers?.remove || []).forEach((h) => proxyReq.removeHeader(h));

    // Forward real IP
    const clientIp = req.ip || req.socket?.remoteAddress;
    if (clientIp) proxyReq.setHeader("X-Real-IP", clientIp);
    proxyReq.setHeader("X-Forwarded-For", clientIp || "unknown");
    proxyReq.setHeader("X-Forwarded-Proto", req.protocol || "http");
  });

  _proxy.on("proxyRes", (proxyRes, req, res) => {
    const latencyMs = Date.now() - (req._startTime || Date.now());

    // Inject response headers
    const responseHeaders = config.headers?.response || {};
    Object.entries(responseHeaders).forEach(([k, v]) => proxyRes.headers[k] = v);

    metrics.recordRequest({
      method: req.method,
      path: req.originalUrl,
      status: proxyRes.statusCode,
      latencyMs,
      target: req._proxyTarget,
    });

    if (config.logging?.requestLog) {
      logger.info(`[Reverse] ${req.method} ${req.originalUrl} → ${req._proxyTarget} ${proxyRes.statusCode} (${latencyMs}ms)`);
    }
  });

  // ── Load Balancer ──────────────────────────────────────────
  if (config.loadBalancer?.enabled) {
    _lb = new LoadBalancer(config.loadBalancer);

    for (const pool of (config.loadBalancer.pools || [])) {
      app.all(`${pool.match}*`, (req, res, next) => {
        req._startTime = Date.now();
        const backend = _lb.getBackend(pool.name, req.ip);
        if (!backend) {
          return res.status(503).json({ error: "Service Unavailable", message: "No healthy backends in pool: " + pool.name });
        }
        req._proxyTarget = backend.url;
        req._lbPool = pool.name;
        req._lbBackendUrl = backend.url;

        _proxy.web(req, res, { target: backend.url, changeOrigin: true }, (err) => {
          if (_lb) _lb.releaseBackend(pool.name, backend.url);
          if (err && !res.headersSent) {
            res.status(502).json({ error: "Bad Gateway" });
          }
        });
      });
    }

    logger.info(`[LB] Load balancer enabled with ${config.loadBalancer.pools?.length} pool(s) using ${config.loadBalancer.algorithm}`);
  }

  // ── Static Routes ──────────────────────────────────────────
  for (const route of (config.routes || [])) {
    if (!route.match || !route.target) continue;

    const middlewares = [];

    // Per-route cache
    if (route.cache?.enabled) {
      middlewares.push(cacheMiddleware(route.cache.ttl));
    }

    const handler = (req, res) => {
      req._startTime = Date.now();
      req._proxyTarget = route.target;

      // Path rewrite
      let targetPath = req.url;
      if (route.pathRewrite) {
        for (const [pattern, replacement] of Object.entries(route.pathRewrite)) {
          targetPath = req.url.replace(new RegExp(pattern), replacement);
        }
      }

      // Per-route header injection
      const routeHeaders = route.headers || {};
      Object.entries(routeHeaders).forEach(([k, v]) => req.headers[k] = v);

      const options = {
        target: route.target,
        changeOrigin: route.changeOrigin !== false,
        timeout: route.timeout || 30000,
        proxyTimeout: route.timeout || 30000,
      };

      if (route.pathRewrite) {
        options.target = route.target;
        req.url = targetPath;
      }

      if (config.logging?.requestLog) {
        logger.debug(`[Reverse] Route "${route.name}": ${req.method} ${req.originalUrl} → ${route.target}${targetPath}`);
      }

      _proxy.web(req, res, options);
    };

    // Register route
    if (middlewares.length) {
      app.all(`${route.match}*`, ...middlewares, handler);
    } else {
      app.all(`${route.match}*`, handler);
    }

    logger.info(`[Reverse] Route "${route.name}": ${route.match}* → ${route.target}`);
  }

  return _proxy;
}

function getProxy() { return _proxy; }
function getLB() { return _lb; }

// WebSocket upgrade support
function handleUpgrade(req, socket, head, config) {
  if (!_proxy) return;
  const logger = getLogger();

  // Match route
  const route = (config.routes || []).find((r) => req.url.startsWith(r.match));
  if (route) {
    logger.info(`[WS] Upgrading WebSocket → ${route.target}`);
    _proxy.ws(req, socket, head, { target: route.target, changeOrigin: true });
  } else if (config.loadBalancer?.enabled && _lb) {
    const pool = (config.loadBalancer.pools || []).find((p) => req.url.startsWith(p.match));
    if (pool) {
      const backend = _lb.getBackend(pool.name, socket.remoteAddress);
      if (backend) {
        logger.info(`[WS] Upgrading WebSocket → ${backend.url}`);
        _proxy.ws(req, socket, head, { target: backend.url, changeOrigin: true });
      }
    }
  }
}

module.exports = { setupReverseProxy, getProxy, getLB, handleUpgrade };
