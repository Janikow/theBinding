#!/usr/bin/env node
"use strict";

/**
 * Generates a self-signed SSL certificate for development/testing.
 * Usage: node src/utils/generateCert.js
 * Requires: openssl in PATH
 */

const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

const SSL_DIR = path.join(__dirname, "../../ssl");

if (!fs.existsSync(SSL_DIR)) fs.mkdirSync(SSL_DIR, { recursive: true });

console.log("Generating self-signed SSL certificate…\n");

const cmd = [
  "openssl req -x509 -newkey rsa:4096",
  "-keyout ssl/server.key",
  "-out ssl/server.crt",
  "-days 365 -nodes",
  `-subj "/C=US/ST=Dev/L=Localhost/O=UltraProxy/CN=localhost"`,
  "-addext 'subjectAltName=DNS:localhost,IP:127.0.0.1'",
].join(" ");

try {
  execSync(cmd, { stdio: "inherit" });
  console.log("\n✓ Certificate generated:");
  console.log(`  ssl/server.crt`);
  console.log(`  ssl/server.key`);
  console.log("\nEnable in config.yaml:");
  console.log("  ssl:");
  console.log("    enabled: true");
  console.log("    cert: ./ssl/server.crt");
  console.log("    key:  ./ssl/server.key\n");
} catch (e) {
  console.error("✗ openssl not found. Install OpenSSL or provide your own certs.");
  process.exit(1);
}
