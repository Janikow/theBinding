"use strict";

const { getLogger } = require("./logger");

class Metrics {
  constructor() {
    this.startTime = Date.now();
    this.reset();
  }

  reset() {
    this.requests = {
      total: 0,
      success: 0,
      error: 0,
      blocked: 0,
      cached: 0,
    };
    this.bytes = {
      sent: 0,
      received: 0,
    };
    this.latency = {
      total: 0,
      count: 0,
      min: Infinity,
      max: 0,
      p50: 0,
      p95: 0,
      p99: 0,
      samples: [],
    };
    this.statusCodes = {};
    this.routes = {};
    this.errors = [];
    this.recentRequests = [];
  }

  recordRequest({ method, path, status, latencyMs, bytesSent, bytesReceived, cached, blocked, error, target }) {
    this.requests.total++;

    if (blocked) {
      this.requests.blocked++;
    } else if (error) {
      this.requests.error++;
      this.errors.push({ time: new Date().toISOString(), method, path, error: String(error).slice(0, 200) });
      if (this.errors.length > 100) this.errors.shift();
    } else if (status >= 200 && status < 400) {
      this.requests.success++;
    }

    if (cached) this.requests.cached++;

    // Status codes
    const code = String(status || 0);
    this.statusCodes[code] = (this.statusCodes[code] || 0) + 1;

    // Bytes
    if (bytesSent) this.bytes.sent += bytesSent;
    if (bytesReceived) this.bytes.received += bytesReceived;

    // Latency
    if (latencyMs != null) {
      this.latency.total += latencyMs;
      this.latency.count++;
      this.latency.min = Math.min(this.latency.min, latencyMs);
      this.latency.max = Math.max(this.latency.max, latencyMs);
      this.latency.samples.push(latencyMs);
      if (this.latency.samples.length > 1000) this.latency.samples.shift();
      this._updatePercentiles();
    }

    // Per-route stats
    const routeKey = target || path || "unknown";
    if (!this.routes[routeKey]) this.routes[routeKey] = { requests: 0, errors: 0, avgLatency: 0, totalLatency: 0 };
    this.routes[routeKey].requests++;
    if (error) this.routes[routeKey].errors++;
    if (latencyMs) {
      this.routes[routeKey].totalLatency += latencyMs;
      this.routes[routeKey].avgLatency = Math.round(this.routes[routeKey].totalLatency / this.routes[routeKey].requests);
    }

    // Recent requests ring buffer
    this.recentRequests.push({
      time: new Date().toISOString(),
      method,
      path: (path || "").slice(0, 100),
      status,
      latencyMs,
      cached: !!cached,
      target: (target || "").slice(0, 60),
    });
    if (this.recentRequests.length > 200) this.recentRequests.shift();
  }

  _updatePercentiles() {
    const sorted = [...this.latency.samples].sort((a, b) => a - b);
    const p = (pct) => sorted[Math.floor((sorted.length - 1) * pct)] || 0;
    this.latency.p50 = p(0.5);
    this.latency.p95 = p(0.95);
    this.latency.p99 = p(0.99);
  }

  getAvgLatency() {
    if (!this.latency.count) return 0;
    return Math.round(this.latency.total / this.latency.count);
  }

  getSummary() {
    return {
      uptime: Math.floor((Date.now() - this.startTime) / 1000),
      requests: this.requests,
      bytes: this.bytes,
      latency: {
        avg: this.getAvgLatency(),
        min: this.latency.min === Infinity ? 0 : this.latency.min,
        max: this.latency.max,
        p50: this.latency.p50,
        p95: this.latency.p95,
        p99: this.latency.p99,
      },
      statusCodes: this.statusCodes,
      routes: this.routes,
    };
  }
}

// Singleton
const metrics = new Metrics();
module.exports = metrics;
