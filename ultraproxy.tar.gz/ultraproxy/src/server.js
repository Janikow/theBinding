"use strict";

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const rateLimit = require("express-rate-limit");
const morgan = require("morgan");
const path = require("path");

const { getLogger } = require("./utils/logger");
const { apiKeyAuth } = require("./middleware/auth");
const { initCache, cacheMiddleware } = require("./middleware/cache");
const { createAdminRouter } = require("./routes/admin");
const { setupReverseProxy } = require("./routes/reverseProxy");
const metrics = require("./utils/metrics");

function buildApp(config) {
  const app = express();
  const logger = getLogger();

  // ── Trust proxy ───────────────────────────────────────────
  if (config.server?.trustProxy) app.set("trust proxy", 1);

  // ── Security headers ──────────────────────────────────────
  app.use(helmet({
    contentSecurityPolicy: false, // Allow admin dashboard to load resources
    crossOriginEmbedderPolicy: false,
  }));

  // ── Compression ───────────────────────────────────────────
  app.use(compression());

  // ── CORS ─────────────────────────────────────────────────
  if (config.cors?.enabled) {
    app.use(cors({
      origin: config.cors.origin || "*",
      methods: config.cors.methods,
      allowedHeaders: config.cors.allowedHeaders,
      credentials: config.cors.credentials || false,
      maxAge: config.cors.maxAge || 86400,
    }));
  }

  // ── Body parsing ──────────────────────────────────────────
  app.use(bodyParser.json({ limit: "50mb" }));
  app.use(bodyParser.urlencoded({ extended: true, limit: "50mb" }));
  app.use(cookieParser());

  // ── HTTP request logging ──────────────────────────────────
  if (config.logging?.requestLog) {
    app.use(morgan((tokens, req, res) => {
      return [
        tokens.method(req, res),
        tokens.url(req, res),
        tokens.status(req, res),
        tokens["response-time"](req, res) + "ms",
        tokens["remote-addr"](req, res),
      ].join(" ");
    }, {
      stream: { write: (msg) => logger.info(msg.trim()) },
      skip: (req) => req.url.startsWith("/api/admin"),
    }));
  }

  // ── Rate limiting ─────────────────────────────────────────
  if (config.rateLimit?.enabled) {
    const limiter = rateLimit({
      windowMs: config.rateLimit.windowMs || 60000,
      max: config.rateLimit.max || 300,
      message: { error: "Too Many Requests", message: config.rateLimit.message },
      standardHeaders: true,
      legacyHeaders: false,
      skip: (req) => {
        const skipPaths = config.rateLimit.skipPaths || [];
        return skipPaths.some((p) => req.path.startsWith(p));
      },
      handler: (req, res) => {
        metrics.recordRequest({ method: req.method, path: req.path, status: 429, blocked: true });
        res.status(429).json({ error: "Too Many Requests", message: config.rateLimit.message });
      },
    });
    app.use(limiter);
  }

  // ── Cache init ────────────────────────────────────────────
  if (config.cache?.enabled) {
    initCache(config);
  }

  // ── API key auth ──────────────────────────────────────────
  app.use(apiKeyAuth(config));

  // ── Health / metrics endpoints ────────────────────────────
  app.get("/health", (req, res) => {
    res.json({
      status: "ok",
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      version: "1.0.0",
    });
  });

  app.get("/metrics", (req, res) => {
    res.json(metrics.getSummary());
  });

  // ── Admin panel ───────────────────────────────────────────
  if (config.admin?.enabled) {
    // Serve static dashboard
    app.use("/api/admin", createAdminRouter(config));
    app.use("/admin", express.static(path.join(__dirname, "../dashboard")));
    app.get("/admin", (req, res) => {
      res.sendFile(path.join(__dirname, "../dashboard/index.html"));
    });
  }

  // ── Reverse proxy routes ──────────────────────────────────
  setupReverseProxy(app, config);

  // ── Catch-all 404 ─────────────────────────────────────────
  app.use((req, res) => {
    res.status(404).json({
      error: "Not Found",
      message: `No route matched: ${req.method} ${req.path}`,
    });
  });

  // ── Error handler ─────────────────────────────────────────
  app.use((err, req, res, next) => {
    logger.error(`[App] Unhandled error: ${err.message}`, { stack: err.stack });
    res.status(500).json({ error: "Internal Server Error", message: err.message });
  });

  return app;
}

module.exports = { buildApp };
