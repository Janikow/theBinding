"use strict";

const http = require("http");
const https = require("https");
const { getLogger } = require("./logger");

class LoadBalancer {
  constructor(config) {
    this.pools = {};
    this.algorithm = config.algorithm || "round-robin";
    this.healthCheck = config.healthCheck || { enabled: false };
    this._counters = {};
    this._connections = {};

    for (const pool of (config.pools || [])) {
      this._initPool(pool);
    }

    if (this.healthCheck.enabled) {
      this._startHealthChecks();
    }
  }

  _initPool(pool) {
    this.pools[pool.name] = pool.backends.map((b) => ({
      url: b.url,
      weight: b.weight || 1,
      healthy: true,
      connections: 0,
      requests: 0,
      failures: 0,
    }));
    this._counters[pool.name] = 0;
  }

  _startHealthChecks() {
    const interval = this.healthCheck.interval || 10000;
    const healthPath = this.healthCheck.path || "/health";
    const timeout = this.healthCheck.timeout || 3000;

    setInterval(() => {
      for (const [poolName, backends] of Object.entries(this.pools)) {
        for (const backend of backends) {
          this._checkHealth(backend, healthPath, timeout);
        }
      }
    }, interval);
  }

  _checkHealth(backend, path, timeout) {
    const url = new URL(path, backend.url);
    const mod = url.protocol === "https:" ? https : http;

    const req = mod.get({ hostname: url.hostname, port: url.port, path: url.pathname, timeout }, (res) => {
      const wasHealthy = backend.healthy;
      backend.healthy = res.statusCode < 500;
      if (!wasHealthy && backend.healthy) getLogger().info(`[LB] Backend ${backend.url} is back online`);
    });

    req.on("error", () => {
      if (backend.healthy) getLogger().warn(`[LB] Backend ${backend.url} is down`);
      backend.healthy = false;
      backend.failures++;
    });

    req.on("timeout", () => { req.destroy(); backend.healthy = false; });
  }

  getBackend(poolName, clientIp) {
    const backends = (this.pools[poolName] || []).filter((b) => b.healthy);
    if (!backends.length) return null;

    let selected;

    switch (this.algorithm) {
      case "least-connections":
        selected = backends.reduce((a, b) => (a.connections <= b.connections ? a : b));
        break;

      case "random":
        selected = backends[Math.floor(Math.random() * backends.length)];
        break;

      case "ip-hash": {
        const hash = (clientIp || "").split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
        selected = backends[hash % backends.length];
        break;
      }

      case "weighted-round-robin": {
        // Build weighted list
        const weighted = [];
        for (const b of backends) for (let i = 0; i < b.weight; i++) weighted.push(b);
        const idx = (this._counters[poolName] || 0) % weighted.length;
        this._counters[poolName] = idx + 1;
        selected = weighted[idx];
        break;
      }

      case "round-robin":
      default: {
        const idx = (this._counters[poolName] || 0) % backends.length;
        this._counters[poolName] = idx + 1;
        selected = backends[idx];
        break;
      }
    }

    if (selected) {
      selected.requests++;
      selected.connections++;
    }

    return selected;
  }

  releaseBackend(poolName, backendUrl) {
    const backends = this.pools[poolName] || [];
    const backend = backends.find((b) => b.url === backendUrl);
    if (backend && backend.connections > 0) backend.connections--;
  }

  getStatus() {
    const status = {};
    for (const [name, backends] of Object.entries(this.pools)) {
      status[name] = backends.map((b) => ({
        url: b.url,
        healthy: b.healthy,
        connections: b.connections,
        requests: b.requests,
        failures: b.failures,
        weight: b.weight,
      }));
    }
    return status;
  }
}

module.exports = LoadBalancer;
