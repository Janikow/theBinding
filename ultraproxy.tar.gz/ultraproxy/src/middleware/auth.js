"use strict";

const jwt = require("jsonwebtoken");
const { getLogger } = require("../utils/logger");

/**
 * API Key middleware — checks X-API-Key header or ?apiKey= query param
 */
function apiKeyAuth(config) {
  return (req, res, next) => {
    if (!config.auth?.enabled) return next();

    const key = req.headers["x-api-key"] || req.query.apiKey;
    const validKeys = config.auth.apiKeys || [];

    if (!key || !validKeys.includes(key)) {
      getLogger().warn(`[Auth] Rejected request from ${req.ip}: invalid API key`);
      return res.status(401).json({ error: "Unauthorized", message: "Valid API key required in X-API-Key header" });
    }

    next();
  };
}

/**
 * Admin auth middleware — checks X-Admin-Key header or ?adminKey= query param
 * Falls back to JWT Bearer token
 */
function adminAuth(config) {
  return (req, res, next) => {
    if (!config.admin?.requireAuth) return next();

    const adminKey = req.headers["x-admin-key"] || req.query.adminKey;
    if (adminKey && adminKey === config.auth?.adminKey) return next();

    // Try JWT
    const authHeader = req.headers.authorization || "";
    if (authHeader.startsWith("Bearer ")) {
      const token = authHeader.slice(7);
      try {
        jwt.verify(token, config.auth?.jwt?.secret || "changeme");
        return next();
      } catch (e) {
        // fall through
      }
    }

    return res.status(401).json({ error: "Unauthorized", message: "Admin access required" });
  };
}

/**
 * JWT issue endpoint helper
 */
function issueToken(config, payload = {}) {
  return jwt.sign(payload, config.auth?.jwt?.secret || "changeme", {
    expiresIn: config.auth?.jwt?.expiresIn || "24h",
  });
}

/**
 * Forward proxy CONNECT auth (Basic auth check)
 */
function checkForwardProxyAuth(config, req) {
  if (!config.forwardProxy?.auth?.enabled) return true;
  const authHeader = req.headers["proxy-authorization"] || "";
  if (!authHeader.startsWith("Basic ")) return false;
  const [user, pass] = Buffer.from(authHeader.slice(6), "base64").toString().split(":");
  return user === config.forwardProxy.auth.username && pass === config.forwardProxy.auth.password;
}

module.exports = { apiKeyAuth, adminAuth, issueToken, checkForwardProxyAuth };
