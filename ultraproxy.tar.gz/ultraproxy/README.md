# ⚡ UltraProxy

A production-grade, fully-featured **forward + reverse proxy** server built with Node.js.

## Features

| Feature | Description |
|---|---|
| 🔀 **Reverse Proxy** | Route incoming requests to any backend with path rewriting |
| 🌐 **Forward Proxy** | Full HTTP + HTTPS CONNECT tunneling (use as system proxy) |
| ⚖️ **Load Balancer** | Round-robin, least-connections, ip-hash, weighted — with health checks |
| 🔒 **Auth** | API key + JWT authentication |
| 💾 **Cache** | In-memory response cache with configurable TTL per route |
| 🚦 **Rate Limiting** | Per-IP rate limiting with skip-list |
| 📊 **Admin Dashboard** | Real-time web UI with metrics, traffic log, LB status |
| 🔌 **WebSocket** | Transparent WS/WSS proxying |
| 🔐 **TLS/SSL** | HTTPS termination with self-signed cert generator |
| 🐳 **Docker** | Single-command deploy with Docker Compose |
| 📝 **Logging** | Rotating file logs + colorized console via Winston |
| ⚙️ **Config** | YAML-based config with env variable overrides |

---

## Quick Start

### 1. Install
```bash
git clone <repo>
cd ultraproxy
npm install
```

### 2. Configure
```bash
cp .env.example .env
# Edit config.yaml to add your routes
```

### 3. Run
```bash
# Development
npm run dev

# Production
npm start
```

---

## Configuration

All settings live in `config.yaml`. Environment variables override YAML values.

### Reverse proxy routes

```yaml
routes:
  - name: "My API"
    match: "/api"
    target: "http://localhost:3000"
    changeOrigin: true
    pathRewrite:
      "^/api": ""       # Strip /api prefix
    cache:
      enabled: true
      ttl: 60

  - name: "My Frontend"
    match: "/"
    target: "http://localhost:5173"
    changeOrigin: true
```

### Load balancer

```yaml
loadBalancer:
  enabled: true
  algorithm: "round-robin"   # round-robin | least-connections | random | ip-hash | weighted-round-robin
  healthCheck:
    enabled: true
    interval: 10000
    path: "/health"
  pools:
    - name: "api"
      match: "/api"
      backends:
        - url: "http://localhost:3001"
          weight: 2
        - url: "http://localhost:3002"
          weight: 1
```

### Forward proxy

```yaml
forwardProxy:
  enabled: true
  port: 3128
  auth:
    enabled: true
    username: "user"
    password: "pass"
  blocklist:
    - "*.ads.com"
    - "tracking.example.com"
```

### Auth (API Key)

```yaml
auth:
  enabled: true
  apiKeys:
    - "your-secret-key"
```

All requests must include: `X-API-Key: your-secret-key`

### SSL/HTTPS

```bash
# Generate a self-signed cert (dev/testing)
npm run generate-cert
```

```yaml
ssl:
  enabled: true
  cert: ./ssl/server.crt
  key:  ./ssl/server.key
```

---

## Using as a Forward Proxy

### System-wide (macOS/Linux)
```
HTTP Proxy:  localhost  Port: 3128
HTTPS Proxy: localhost  Port: 3128
```

### curl
```bash
curl -x http://localhost:3128 https://example.com
```

### Environment variables
```bash
export HTTP_PROXY=http://localhost:3128
export HTTPS_PROXY=http://localhost:3128
# Now all HTTP tools (pip, npm, wget, etc.) route through the proxy
```

### With auth enabled
```bash
curl -x http://user:pass@localhost:3128 https://example.com
```

---

## Admin Dashboard

Visit: **http://localhost:8080/admin**

Features:
- Live request metrics (total, RPS, success rate, latency percentiles)
- Per-route traffic breakdown
- Real-time traffic log with method/status/latency
- Load balancer backend health
- Cache hit rate and stats
- Error log
- Config viewer (secrets redacted)
- Process/memory info

---

## API

| Endpoint | Description |
|---|---|
| `GET /health` | Health check |
| `GET /metrics` | JSON metrics |
| `GET /api/admin/metrics` | Detailed metrics |
| `GET /api/admin/metrics/recent` | Recent requests |
| `GET /api/admin/metrics/errors` | Error log |
| `POST /api/admin/metrics/reset` | Reset metrics |
| `GET /api/admin/cache/stats` | Cache stats |
| `DELETE /api/admin/cache` | Clear cache |
| `GET /api/admin/lb/status` | Load balancer status |
| `GET /api/admin/config` | View config (redacted) |
| `POST /api/admin/config/reload` | Reload config.yaml |
| `GET /api/admin/process` | Node process info |

---

## Docker

```bash
# Build and run
docker compose up -d

# View logs
docker compose logs -f

# Stop
docker compose down
```

Ports exposed:
- `8080` — HTTP / reverse proxy
- `8443` — HTTPS (when enabled)
- `3128` — Forward proxy

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `8080` | HTTP port |
| `HTTPS_PORT` | `8443` | HTTPS port |
| `FORWARD_PROXY_PORT` | `3128` | Forward proxy port |
| `ADMIN_PORT` | `9000` | Admin port (future) |
| `NODE_ENV` | `development` | Node environment |
| `LOG_LEVEL` | `info` | Log level |
| `AUTH_ENABLED` | `false` | Enable API key auth |
| `ADMIN_KEY` | — | Admin dashboard key |
| `JWT_SECRET` | — | JWT signing secret |
| `CONFIG_PATH` | `./config.yaml` | Config file path |

---

## Production Checklist

- [ ] Change `auth.adminKey` and `auth.apiKeys` in config
- [ ] Change `auth.jwt.secret`
- [ ] Enable `auth.enabled: true`
- [ ] Set `NODE_ENV=production`
- [ ] Configure real SSL cert (Let's Encrypt recommended)
- [ ] Set `LOG_LEVEL=warn` for less noise
- [ ] Review `forwardProxy.blocklist`
- [ ] Set up log rotation (already handled by `winston-daily-rotate-file`)
- [ ] Put behind a firewall — restrict port `3128` to trusted IPs only

---

## License

MIT
